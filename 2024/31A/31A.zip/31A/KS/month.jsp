﻿<%@ page contentType="text/html; charset=UTF-8" %>
<html>
<title>season</title>
<body>
<form _________(1)_______="showmonth.jsp" method=post >
<h4>请选择季节</h4>
<select name="wk">  
  <Option value="1">春季
  <Option value="2">夏季
  <Option value="3">秋季
  <Option value="4">冬季
</select>
<p>
<input type="_______(2)_______" value="显示月份" name="submit">
</form>
</body> 
</html> 