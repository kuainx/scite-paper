<html>
<%@ page contentType="text/html; charset=UTF-8" %>
<title>Month</title>
<body>
<% 
String days=____________(3)_________.getParameter("wk");
int day=__________(4)_________.parseInt(days);
switch(__________(5)_________) {
case 1:%>
  <img src="spring.jpg"/><br>
<%   out.println("春季：3，4，5月");
   break;
case 2:%>
  <img src="summer.jpg"/><br>
<%  
   out.println("夏季：6，7，8月");
   break;
case 3:%>
  <img src="autumn.jpg"/><br>
<%  
   out.println("秋季：9，10，11月");
   break;
case 4:%>
  <img src="winter.jpg"/><br>
<%  
   out.println("冬季：12，1，2月");
   break;
}
%>
</body> 
</html> 