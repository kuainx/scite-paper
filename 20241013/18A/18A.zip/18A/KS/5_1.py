# 导入相关库
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
import matplotlib.pyplot as plt
from matplotlib import rcParams
from sklearn.preprocessing import MinMaxScaler
import numpy as np

# 载入数据
data = pd.read_csv('C:\\KS\\example.csv',encoding='gbk')
X = __________________                                    #【1】提取'特征3'数据列
y = data['目标值']

# 将样本数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = __________________     #【2】将数据集划分为训练集和测试集，测试集所占比例为20%， 固定随机数种子为21

#归一化数据
scaler = MinMaxScaler()
X_train_scaled = __________________                      #【3】对训练集进行归一化拟合和转换
X_test_scaled = scaler.transform(X_test)

# 创建模型
model = linear_model.LinearRegression()

# 训练模型
model.fit(X_train_scaled, y_train)

#输出模型的系数和截距
print('模型的系数:{:.4f}'.format(__________________))     #【4】输出模型系数
print('模型的截距:{:.4f}'.format(model.intercept_))

# 模型预测
y_pred = model.predict(X_test_scaled)

# 模型评估,可视化比较预测值和真实值
print('平均绝对误差:{:.4f}' .format(__________________)) #【5】输出模型平均绝对误差MAE
print('均方误差:{:.4f}'.format(mean_squared_error(y_test,y_pred)))
print('决定系数:{:.4f}'.format(r2_score(y_test,y_pred))) 

# 绘图显示
rcParams['font.sans-serif'] = 'SimHei'
rcParams['axes.unicode_minus'] = False
fig=plt.figure(figsize=(6,4))
plt.plot(X_test,y_pred,color='blue',label='回归线')
plt.scatter(X_test, y_test, color='orange', marker='o', label='测试集')
plt.legend(['回归线','测试集'])
plt.xlabel('特征3')  
plt.ylabel('目标值')
plt.grid()
plt.show()
