import pandas as pd
import matplotlib.pyplot as plt   
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus']=False
jieqi = pd.read_csv('C:\\KS\\jieqi.csv',encoding='utf-8-sig')
while True:
    ________("请选择节气最低温度数据点标记风格，输入“菱”是菱形，输入“圆”是圆形：") #【1】使用输入函数给xz变量赋值
    if xz=='菱':
        bj='d'
        break
    elif xz=='圆': 
        __________                                                             #【2】赋值圆形标记风格，对应的值为'o'
        break
    else:        
        print("输入信息有误，请重新选择标记类型")
        
term = jieqi.Term
maxtemp = jieqi.Maxtemp
mintemp = jieqi.Mintemp

plt.title('2023年上海市二十四节气的气温分布')   
plt.xlabel('节气')                               
_________                                                                      #【3】设置图表的y坐标轴标签为'温度(摄氏温度)'   
                  
plt.scatter(term, mintemp, marker=bj,label='最低温度')
plt.scatter(term, maxtemp,label='最高温度')
plt.xticks(rotation=45)                           
___________                                                                    #【4】设置图表的y坐标轴范围为(-10, 40)                                                

___________                                                                    #【5】设置图例
plt.grid()  
plt.show()