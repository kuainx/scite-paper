# 导入库
import tensorflow as tf                                                        #【_1_】
import matplotlib.pyplot as plt

# 载入fashion_mnist数据集 
fashion_mnist = tf.keras.datasets.fashion_mnist                                 
(X_train, y_train), (X_test, y_test) = fashion_mnist.load_data()   

# 建立映射表
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']
			   
plt.figure(figsize=(12,8))
for i in range(0, 9):
    plt.subplot(3,3,i+1)
    plt.imshow(X_train[i], cmap='gray')
    plt.xticks([])
    plt.yticks([])
    plt.title("True="+str(class_names[y_train[i]]))                            
plt.show()                                                                     #【_2_】
 
# 利用reshape函数转换数字图像
X_train_reshape = X_train.reshape(X_train.shape[0], 28*28)                    
X_test_reshape = X_test.reshape(X_test.shape[0], 28*28) 

# 归一化数字图像
X_train_norm, X_test_norm = X_train_reshape / 255.0, X_test_reshape / 255.0  

# 构建Sequential模型
model = tf.keras.models.Sequential() 
model.add(tf.keras.layers.Dense(40,input_dim=28*28,activation='relu',name='Hidden1'))
model.add(tf.keras.layers.Dense(40, activation='relu', name='Hidden2'))        
model.add(tf.keras.layers.Dense(10,activation='softmax',name='Output'))        #【_3_】     

# 打印模型概况 		   
print(model.summary())		   

# 模型编译	
print('compiling...\n')	   
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])                                            

print('fitting...\n')			  
model.fit(X_train_norm, y_train, epochs=4, validation_split=0.25, verbose=2) 

print('evaluating ...\n')
model.evaluate(X_test_norm, y_test, verbose=2)                                  #【_4_】 

modelname='model_2024.h5'
print('model saving ...\n')
model.save(modelname)   
 
print('loading model ...\n')
model = tf.keras.models.load_model(modelname)                                   #【_5_】
print('predicting...\n')
prediction=model.predict_classes(X_test_norm)

print("{:15}\t{:15}".format("True","Prediction"))
for i in range(0, 9):
    print("{:15}\t{:15}".format(str(class_names[y_test[i]]),str(class_names[prediction[i]])))