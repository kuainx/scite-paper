import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#设置亚洲文字显示宽度
pd.set_option("display.unicode.east_asian_width",True)
pd.set_option("display.unicode.ambiguous_as_wide",True)

#1）从文件ScenicSpots.csv读入数据
spots = pd.read_csv("ScenicSpots.csv",encoding ="gbk")
print(spots)

#2）统计不同区的景点总数，并按景点总数降序排列(替换原数据)；
tspot = spots.groupby(by = ["所属区"]).【1】
tspot.columns=['景点数']
tspot.【2】(by = ["景点数"],ascending=False,inplace=True)
print(tspot)
plt.rcParams['font.sans-serif']= ['SimHei']

#3）绘制柱形图（如图1所示）反映各区景点数高低情况。
tspot.【3】
plt.title("上海主要景点各区分布情况")
plt.【4】(np.arange(0,21,2)) #将y轴刻度最大值设置为20，间隔2
plt.grid()
plt.show()
