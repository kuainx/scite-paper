#源程序文件fill_1.py 
import numpy as np
import pandas as pd
#设置亚洲文字显示宽度
pd.set_option("display.unicode.east_asian_width",True)
pd.set_option("display.unicode.ambiguous_as_wide",True)
#1）为100人随机生成7天的早餐消费金额，计算每人的早餐周平均消费金额
a=np.random.【1】(3,20,(100,7))
print(a[:10])
b=a.mean(axis=1)
print(b)

#2）统计两类周平均消费金额的人数并显示
x1=b[【2】].size
print("消费金额在5至10元的人数：",x1)
x2=b[b>15].size
print("消费金额大于15元的人数：",x2)

#3）计算每人的周消费总金额，统计总额小于50元的人数。
asum=a.sum(axis=1)
y1=【3】.size
print("周消费总金额小于50元的人数：",y1)


