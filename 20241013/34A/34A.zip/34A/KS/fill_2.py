import pandas as pd
energyArr = [["广东",33.07,199.81],
["江苏",10.96,97.99],
["浙江",10.54,133.95],
["山东",7.39,90.65],
["湖北",8.38,39.59],
["海南",2.35,18.61],
["江西",1.99,23.56],
["广西",2.9,43.62],
["云南",3.24,21.35]]
#设置亚洲文字显示宽度
pd.set_option("display.unicode.east_asian_width",True)
pd.set_option("display.unicode.ambiguous_as_wide",True)

#1)创建保存各省份新能源车与充电桩保有量的数据对象。
title =("province","energy","vehicle") #对应表1的第一行3个标题
df1 = pd.DataFrame(【1】)
print(df1)

#2)添加一条安徽省的新能源车与充电桩数据
de = {"province":["安徽"],"energy":[6.85],"vehicle":[41.03]}
df2 = pd.DataFrame(de)
df = pd.concat(【2】,ignore_index=True)
print(df)

#3)增加一列“ratio”，记录充电桩与新能源车的数量比，输出比例小于10%的省份
df["ratio"]=df.energy/df.vehicle
print("充电桩与新能源车的比例小于10%的省份:\n")
print(df.loc[【3】,"province"])
