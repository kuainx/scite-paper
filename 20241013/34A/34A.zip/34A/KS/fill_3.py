# -*- coding: utf-8 -*-
import pandas as pd
#设置亚洲文字显示宽度
pd.set_option("display.unicode.east_asian_width",True)
pd.set_option("display.unicode.ambiguous_as_wide",True)

#1) 读取gold_data.csv文件中的数据；
data= pd.read_csv('gold_data.csv')
print(data.head())

#2)判断数据中是否存在缺失值，并输出各列的缺失值情况；
is_NAN = data.【1】.any()
print(is_NAN)
#交易量(Volume)列缺失的值，使用前一天的交易量值填充；
【2】(method='ffill', inplace=True)

#3)计算2022年金价的平均收盘价(Close/Last)；
jj=data.loc[data["Date"]>='01/01/2022','Close/Last']
print("2022年金价的平均收盘价：{:.2f}".format(【3】))

