import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import javax.swing.*;

public class GC4 extends JFrame {
	int[][] posLei= {{1,2},{2,1},{2,3},{3,2}};  //4���׵�λ��
	public void paint(g){    
		super.paint(g);
		int w=getSize().width;	
		int h=getSize().height;	
		g.setColor(Color.BLACK);  
		int xunit=(w-70*2)/3;	//X������Ӽ��
		int yunit=(h-70*2)/3;	//y������Ӽ��
		int startx=70,starty=70;  //������������Ͻ�
		for (int i=0;i<=3;i++) {  //��������
			g.drawLine(70,i*yunit+70,70+3*xunit,i*yunit+70); 
			g.drawLine(i*xunit+70,70,i*xunit+70,70+3*yunit);
		}
		g.setFont(new Font("����",Font.PLAIN,20));
		g.drawString(60, 60,"����"+posLei.length+"����");  
		g.setColor(Color RED);    
		for (int i=0;i<posLei.length;i++) {
			int row=posLei[i][0];
			int col=posLei[i][1];
			int x0=startx+(col-1)*xunit;   
			int y0=starty+(row-1)*yunit;
			g.drawLine(x0, y0, x0+xunit, y0-yunit);  
			g.drawLine(x0+xunit, y0, x0, y0+yunit);
		}	
	}
    public static void main(String[] args) {
        GC4 frame = new GC4();
        frame.setTitle("��");
        frame.setSize(450, 450);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}






