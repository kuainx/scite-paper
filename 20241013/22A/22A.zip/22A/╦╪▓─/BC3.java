import java.io.*;
public class BC3 {
	public static void main(String[] args) {
		String filePath = "C:\\KS\\foodinfo.txt";
		try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
			//���ڴ����Ӵ���
			
			
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
