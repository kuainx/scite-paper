#include <stdio.h>
#include <stdlib.h>
void select(FILE *fp1, int x)
{
    int   num, score1, score2;
    char  name[20];
    while ( 1 );
    {
        fscanf(fp1, "%d%s%d%d", &num, name, &score1, &score2);
        if (num == 0)
            continue;
        if (x<score2)
        {
            printf( "%3d  %-7s  %3d  %3d\n", num, name, score1, score2);
        }
    }
}
int main(void)
{
    FILE  fp1;
    int   x;
    fp1 = fopen("studentA_3_3.txt", "r");
    if (fp1 == NULL)
    {
        printf( "File Open Error!\n" );
        exit(0);
    }
    scanf("%d", &x);
    select(fp1, x);
    fclose(fp1);
    return 0;
}
