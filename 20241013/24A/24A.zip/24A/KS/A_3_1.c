#include <stdio.h>
#include <math.h>
int main(void)
{
    float x,y;
    printf("input x:");
    scanf("%d", &x);
    if (x<0)
        y = sqrt(1-3*x);
    else if (x=0)
        y = 2*x*x+2;
    else if(x>0 && x<3)
        y = 4*x-10;
    else
        y = (x+2)/(1-5x);
    printf("x=%f, y=%.2f\n",x,y);
    return 0;
}
