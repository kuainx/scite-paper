package com.example.iotclient;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.alibaba.fastjson.JSON;

public class LoginActivity extends Activity {
    private Button mLoginBtn;
    private EditText mAccountEt;
    private EditText mPasswordEt;
    private EditText mIpEt;
    private EditText mPortEt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mAccountEt = (EditText) findViewById(R.id.et_account);
        mPasswordEt = (EditText) findViewById(R.id.et_password);
        mIpEt = (EditText) findViewById(R.id.et_ip);
        mPortEt = (EditText) findViewById(R.id.et_port);
        mLoginBtn = (Button) findViewById(R.id.btn_login);

    }

}