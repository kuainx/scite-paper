﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 调试改错题
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /****************************************************/
        /****                                            ****/
        /****    调试改错题 1 “通行码判别”相关代码段   ****/
        /****                                            ****/
        /****  （本题程序代码中有 3 个错，请调试改正）   ****/
        /****                                            ****/
        /****************************************************/

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1 or listBox2.SelectedIndex == -1)   
            {
                MessageBox.Show("请选择出行情况和交通工具");
                return;
            }
            if (listBox1.SelectedIndex == 0)
                button1.BackColor = Color.Red;
            else 
            {
                if (listBox2.SelectedIndex == 1)      
                    button1.BackColor = Color.Red;
                else if (listBox2.SelectedIndex == 1)
                    button1.BackColor = Color.Yellow;
                else
                    button1.ForeColor = Color.Green;      
            }
        }


        /****************************************************/
        /****                                            ****/
        /****    调试改错题 2 “确诊人数图”相关代码段   ****/
        /****                                            ****/
        /****  （本题程序代码中有 4 个错，请调试改正）   ****/
        /****                                            ****/
        /****************************************************/

        private void button3_Click(object sender, EventArgs e)
        {
            int[] num = new int[3];
            int[] numByRatio = new int[3];
            TextBox[] tbox = { textBox1, textBox2, textBox3 };
            Label[] lb = { label4, label5, label6 };
            int max = 0;
            for (int i = 0; i < num.Length; i++)
            {
                num[i] = int.Parse(tbox[i]);  
                numByRatio[i] = num[i];
                if (num[i] < max)         
                    max = num[i];
            }

                // 对超过20的最大输入数计算缩放比例，并按这个缩放比例，重新计算3个数对应的"■"个数

            if (max > 20)     
            {
                double ratio = (double)20 / max;
                for (int i = 0; i < numByRatio ; i++)    
                {
                    numByRatio[i] = Math.Round(numByRatio[i] * ratio);  
                }
            }
            string s = "";
            for (int i = 0; i < numByRatio.Length; i++)
            {
                s = s.PadRight(numByRatio[i], '■');
                lb[i].Text = s + " " + num[i].ToString();
                s = "";
            }
        }


        /****************************************************/
        /****                                            ****/
        /**** 调试改错题 3 “十进制转二进制”相关代码段  ****/
        /****                                            ****/
        /****  （本题程序代码中有 4 个错，请调试改正）   ****/
        /****                                            ****/
        /****************************************************/

        string toBinary(int n)
        {
            if (n == 0)
                return  "";  
            else
            {
                string ls = toBinary(n % 2);  
                string r = (n / 2).ToString();   
                return ls + r;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int n;
            if (textBox5.Text == 0)   
            {
                textBox5.Focus();
                return;
            }
            n = Convert.ToInt32(textBox4.Text);     
            if (n == 0)
                textBox4.Text = "0";
            else
                textBox4.Text = toBinary(n);
        }


        /****************************************************/
        /****                                            ****/
        /****     调试改错题 4 “登录”  相关代码段      ****/
        /****                                            ****/
        /****  （本题程序代码中有 4 个错，请调试改正）   ****/
        /****                                            ****/
        /****************************************************/

        int t;
        private void timer1_Tick(object sender, EventArgs e)
        {
            label14.Text = t.ToString();
            if (t > 0)
                t++;        
            else
            {
                timer1.Enabled = false;
                label17.Text = "";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox8.Text == "Student" || textBox7.Text == "123456")      
            {
                if (textBox6.Text == label17.Text)
                    MessageBox.Show("登录成功！");
                else
                    MessageBox.Show("登录失败！验证码错误！", "警告");
            }
            else
                MessageBox.Show("登录失败！用户名或密码错误");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string yzm = "";
            int j;
            Random rd = new Random();
            for (j = 0; j < 5; j++)
            {
                yzm += rd.Next(65, 89);  
            }
            label17.Text = yzm;
            timer1.Enabled = false;    
            t = 100;
        }

    }
}
