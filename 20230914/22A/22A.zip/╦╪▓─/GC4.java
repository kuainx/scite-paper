using java.awt.*;
public class GC4 extends javax.swing.JFrame {
    public void paint(Graphics g)
    {
        int x0=getSize().width/2;	//x0�ǰ��������X����
        int y0=getSize().height/2;	//y0�ǰ��������Y����
        Color[] colors={Color.RED,Color.WHITE,Color.GREEN,Color.WHITE,Color.RED,Color.WHITE};
        int[] score=new int[]{1,3,5,7,9,10}; 
        int idx=0;
        int step=25;  //�����
        int r=y0-50;  
        for(idx<colors.length;r-=step)   
        {
            g.setColor(colors[idx]);
            g.fillOval(x0-r,y0-r,2*r,r); 
            g.setColor(Color.BLACK);   
            g.setFont( Font("����", Font.BOLD,18));  
            g.drawString(""+score[idx], x0-5, y0-r+20);
            idx++;       
        }
    }

    public static void main(String[] args) {
        GC4 t = new GC4();
        t.setTitle("����");
        t.setSize(600, 400);
        t.setVisible(true);
    }
}




