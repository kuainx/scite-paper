﻿import socket
import json
import _thread
import time

ip = ''
allowedUser = dict(用户名 = '', 密码 = '')
dataFromSource = ''

def getConfig():
    pass

def getData():
    pass

def clientComm():
    pass

def getFromClient(s, user):
    pass

def sendToClient(s, user):
    pass

def main():
    getConfig()
    _thread.start_new_thread(getData, ())
    clientComm()

main()

