import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#设置亚洲文字显示宽度
pd.set_option("display.unicode.east_asian_width",True)
pd.set_option("display.unicode.ambiguous_as_wide",True)

#1) 从文件中读出台风数据；
filename = 'Typhoon.csv'
winds = pd.【1】(filename)
print(winds[0:5])

#2）查看是否存在缺失数据，删除包含缺失数据的样本；
print(winds.isnull())
【2】(inplace = True)

#3）输出达到超强台风等级的台风名；
names = winds.loc[ 【3】,"windname"].unique()
print("\n达到超强台风等级：\n", names)











