from pandas import DataFrame
from pandas import Series
import numpy as np
import matplotlib.pyplot as plt

#设置亚洲文字显示宽度
pd.set_option("display.unicode.east_asian_width",True)
pd.set_option("display.unicode.ambiguous_as_wide",True)

#1)记录表1的数据，绘制折线图分析各品牌销量发展趋势;
index = ['Huawei','Apple','OPPO','vivo','Mi'];
columns = ['Y2015','Y2016','Y2017','Y2018']
data = np.array( [ [62.9,76.6,90.9,104.97], [58.4,44.9,41.1,36.32],
         [35.3,78.4,80.5,78.94],[35.1,69.2,68.6,75.97],
         [64.9,41.5,55.1,51.99] ] )

sales = DataFrame(【1】)
print(sales)

#绘制折线图
psales = DataFrame(data.T, columns, index)
print(psales)
plt.rcParams['font.sans-serif'] = ['SimHei']
【2】(title='2015~2018国内手机销量',linewidth=2, marker='o',
        linestyle='dashed',grid=True,alpha=0.9)
plt.show()

#2)计算2018年各品牌手机的同比增幅，并在原数据中增加新列“2018同比增幅”；
sales["INC2018"] =【3】
print(sales)


