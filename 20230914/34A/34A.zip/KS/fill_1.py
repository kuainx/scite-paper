﻿# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
#设置亚洲文字显示宽度
pd.set_option("display.unicode.east_asian_width",True)
pd.set_option("display.unicode.ambiguous_as_wide",True)

#设置显示精度为两位小数
np.set_printoptions(precision=2, suppress=True)

#1）使用数组记录6次生产的商品产量（千件），分别为10,5,7,9,11,8；
output = 【1】

#2)根据公式计算每次生产商品的成本；
cost = 0.14*output + 42.7 
print( '1:cost: ',cost)

#3)实际成本围绕计算的成本值上下波动，波动值服从均值为0，方差为2的正态分布。
#随机生成6个数据，模拟每次的波动；
varcost = np.【2】(0,2,6) 
print( '2:variance: ',varcost)

#4）加上波动值，计算6次生产商品的实际成本。
cost =【3】
print( '3:cost: ',cost)


