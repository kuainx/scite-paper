#导入库
from sklearn.datasets import load_wine
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler

#加载红酒品类数据集
wine = load_wine()
X_train, X_test, y_train, y_test = train_test_split(____________, random_state=3)#【1】分割红酒品类数据集，产生训练集和测试集，测试集所占比例为30%，随机数种子为3

#标准化数据
ss=StandardScaler()
X_train=ss.fit_transform(X_train)
X_test=____________                                                     #【2】对测试集进行标准化转换

#利用KNN模型进行分类
knc = ____________________                                              #【3】创建分类器对象
knc.fit(X_train, y_train)
y_predict = knc.predict(X_test)

#类别预测
X_sample=np.array([[14.2, 1.7, 2.4, 15.6, 127, 2.8, 3.1, 0.3, 2.3, 5.6, 1, 3.9, 1065]])
y_sample=_________________                                              #【4】对未知类别的样本数据点进行类别预测
print('The type of Wine is', y_sample)

#测试与性能评估
print('The accuracy is {:.4f}'.format(knc.score(X_test, y_test)))
print(_______________________)                                          #【5】根据测试集的真实分类和预测结果，计算并展示主要分类指标的文本报告