#导入库
import tensorflow as tf                                                                   #【_1_】
import matplotlib.pyplot as plt

#载入Fashion-MNIST数据集
fashion_mnist = tf.keras.datasets.fashion_mnist
(X_train, y_train), (X_test, y_test) = fashion_mnist.load_data()  

#利用reshape函数转换数字图像
X_train_reshape = X_train.reshape(X_train.shape[0], 28*28) 
X_test_reshape = X_test.reshape(X_test.shape[0], 28*28)  

#归一化数字图像
X_train_norm, X_test_norm = X_train_reshape / 255.0, X_test_reshape / 255.0 

#显示训练集第11幅图像
plt.figure() 
plt.imshow(X_train[10], cmap='gray')  
plt.show()

#构建Sequential模型
model = tf.keras.models.Sequential()                                     
model.add(tf.keras.layers.Dense(50,input_dim=28*28,activation='relu', name='Hidden1'))  #【_2_】
model.add(tf.keras.layers.Dense(50, activation='relu', name='Hidden2'))
model.add(tf.keras.layers.Dense(50, activation='relu', name='Hidden3'))
model.add(tf.keras.layers.Dense(10,activation='softmax',name='Output'))  

#打印模型的概况
print(model.summary())

#模型编译
print('compiling ...\n')
model.compile(optimizer='sgd',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

print('fitting ...\n')
model.fit(X_train_norm, y_train, epochs=5,  verbose=2,  validation_split=0.2)             #【_3_】  

print('\n evaluating ...\n')
model.evaluate(X_test_norm, y_test)                                                       #【_4_】                                                                         

print('\n saving ...\n')
model.save('model_2023.h5')                                                          

print('\n loading ...\n')
model = tf.keras.models.load_model('model_2023.h5')                                       #【_5_】