﻿import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
cars = pd.read_csv('C:\\KS\\car.csv', encoding='utf-8')
brand = cars.Brand  
sales = cars.Sales 
while True:
    ys=input("请选择条形图边框线颜色，输入“黑”是黑色边框线，输入“红”是红色边框线：")
    if _________ :                                                              #【1】判断输入的值是否是'黑'
        color= 'black' 
        break
    elif ys=='红':
        _________                                                               #【2】赋值颜色红色，对应的值为‘red’
        break
    else: 
        print("输入信息有误，请重新选择线型")
plt.title('2023年某月我国轿车品牌/车型销量TOP10')
plt.xlabel('品牌/车型')
_________                                                                       #【3】设置图表的y坐标轴标签为'销量（万辆）'
plt.xticks(rotation=45) 

_________(brand, sales, color='b', edgecolor=color, label='销量')               #【4】绘制条形图

plt.legend()
plt.grid()
_________                                                                       #【5】显示图形