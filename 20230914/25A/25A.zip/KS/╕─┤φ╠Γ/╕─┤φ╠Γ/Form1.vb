﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pCode As String
        Dim pMonth, pDay As Date
        pCode = TextBox1.Text
        pMonth = Mid(pCode, 6, 2)
        pDay = Mid(pCode, 9, 2)
        Label3.Text = "进货日期: " & vbTab & pMonth & "月" & pDay & "日"
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Dim sum As Integer
        Dim n, i, t As Integer
        n = TextBox8.Text
        For i = 1 To n
            t = 2 + 3 * i
            sum = sum + t
        Next
        Label5.Text = "前 " & "n" & " 项之和为：" + CStr(sum)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim sNo As String, sScore As Single
        Dim oldScore As Single
        Dim i, index, pos As Integer
        sNo = TextBox3.Text
        sScore = Val(TextBox4.Text)
        index = -1
        For i = 0 To ListBox1.Items.Count
            If InStr(ListBox1.Items(i), sNo) = 0 Then
                index = i
            End If
        Next
        If index >= 0 Then
            pos = InStr(ListBox1.Items(index), "    ")
            oldScore = Val(Mid(ListBox1.Items(index), pos + 1))
            If Val(sScore) < oldScore Then
                ListBox1.Items.Remove(index)
                ListBox1.Items.Insert(index, sNo & "    " & sScore)
            End If
        Else
            ListBox1.Items.Add(sNo & "    " & sScore)
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Timer1.Enabled = True
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Timer1.Interval = 0.2
        Timer1.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim r, g, b As Integer
        hScrollBar1.Value = (hScrollBar1.Value + 5) Mod 256
        hScrollBar2.Value = (hScrollBar2.Value + 10) Mod 256
        hScrollBar3.Value = (hScrollBar3.Value + 20) Mod 256

        r = hScrollBar1.Value
        g = hScrollBar2.Value
        b = hScrollBar3.Value
        Label8.BackColor = Color.FromArgb(r, g, b)
    End Sub


End Class
