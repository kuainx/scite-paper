﻿Imports System.Data
Imports System.Data.OleDb
Public Class Form1
    Dim strConn = "provider=microsoft.ace.oledb.12.0;data source= University.accdb"
    '一般情况，针对日期格式（yyyy/mm/dd）类型操作，其SQL语句如下： "...where 日期=#" & 文本框 & "#"
End Class
